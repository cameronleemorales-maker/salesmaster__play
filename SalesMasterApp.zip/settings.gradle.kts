
rootProject.name = "SalesMasterApp"
include(":app")
