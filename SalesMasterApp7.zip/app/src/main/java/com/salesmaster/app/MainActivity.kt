package com.salesmaster.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
import android.widget.LinearLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
        }
        val tv = TextView(this).apply {
            text = "Hello from SalesMaster! ✅"
            textSize = 22f
        }
        root.addView(tv)
        setContentView(root)
    }
}
