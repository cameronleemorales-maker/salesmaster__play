package com.salesmaster.app

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val inputKey = findViewById<EditText>(R.id.inputApiKey)
        val inputModel = findViewById<EditText>(R.id.inputModel)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val txtStatus = findViewById<TextView>(R.id.txtStatus)

        val prefs = getSharedPreferences("salesmaster", Context.MODE_PRIVATE)
        inputKey.setText(prefs.getString("openai_key", ""))
        inputModel.setText(prefs.getString("openai_model", "gpt-4o-mini"))

        btnSave.setOnClickListener {
            val key = inputKey.text.toString().trim()
            val model = inputModel.text.toString().trim().ifEmpty { "gpt-4o-mini" }
            prefs.edit().putString("openai_key", key).putString("openai_model", model).apply()
            txtStatus.text = "Saved ✓"
        }
    }
}
