package com.salesmaster.app

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class ObjectionActivity : AppCompatActivity() {

    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_objection)

        val inputObjection = findViewById<EditText>(R.id.inputObjection)
        val btnAsk = findViewById<Button>(R.id.btnAsk)
        val txtAnswer = findViewById<TextView>(R.id.txtAnswer)

        val prefs = getSharedPreferences("salesmaster", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("openai_key", "") ?: ""
        val model = prefs.getString("openai_model", "gpt-4o-mini") ?: "gpt-4o-mini"

        btnAsk.setOnClickListener {
            val objection = inputObjection.text.toString().trim()
            if (objection.isEmpty()) {
                Toast.makeText(this, "Type an objection", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val key = prefs.getString("openai_key", "") ?: ""
            if (key.isEmpty()) {
                txtAnswer.text = "Add your OpenAI API key in Profile first."
                return@setOnClickListener
            }

            callOpenAI(key, model, objection) { text ->
                runOnUiThread { txtAnswer.text = text }
            }
        }
    }

    private fun callOpenAI(apiKey: String, model: String, objection: String, onDone: (String) -> Unit) {
        val url = "https://api.openai.com/v1/chat/completions"
        val media = "application/json; charset=utf-8".toMediaTypeOrNull()
        val messages = JSONArray().apply {
            put(JSONObject(mapOf("role" to "system", "content" to "You are a sales coach. Give concise, high-converting rebuttals.")))
            put(JSONObject(mapOf("role" to "user", "content" to "Prospect objection: " + objection)))
        }
        val bodyJson = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("temperature", 0.7)
        }.toString()

        val req = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer " + apiKey)
            .post(RequestBody.create(media, bodyJson))
            .build()

        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                onDone("Demo answer (offline):
- Acknowledge the concern
- Reframe around ROI
- Provide proof
- Ask a closing question")
            }
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    val out = try {
                        val s = it.body?.string() ?: ""
                        val obj = JSONObject(s)
                        val choices = obj.optJSONArray("choices")
                        if (choices != null && choices.length() > 0) {
                            choices.getJSONObject(0).optJSONObject("message")?.optString("content", "No content") ?: "No content"
                        } else {
                            "No choices"
                        }
                    } catch (e: Exception) {
                        "No response text"
                    }
                    onDone(out)
                }
            }
        })
    }
}
