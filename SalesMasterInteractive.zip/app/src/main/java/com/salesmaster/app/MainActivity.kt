package com.salesmaster.app

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Build UI
        val root = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 48)
        }
        root.addView(col)

        val title = TextView(this).apply {
            text = "SalesMaster"
            textSize = 24f
        }
        val counter = TextView(this).apply {
            text = "Free answers left: 4"
        }
        val apiLabel = TextView(this).apply { text = "API URL (optional):" }
        val apiInput = EditText(this).apply {
            hint = "http://127.0.0.1:4242  (Termux server)"
        }
        val prompt = EditText(this).apply {
            hint = "Type a prospect objection..."
            minLines = 3
        }
        val ask = Button(this).apply {
            text = "Get AI Answer"
        }
        val answerLabel = TextView(this).apply { text = "Answer:" }
        val answer = TextView(this).apply {
            text = ""
            setPadding(16,16,16,16)
        }

        col.addView(title)
        col.addView(counter)
        col.addView(apiLabel)
        col.addView(apiInput)
        col.addView(prompt)
        col.addView(ask)
        col.addView(answerLabel)
        col.addView(answer)

        setContentView(root)

        // Prefs for API url + remaining
        val prefs = getSharedPreferences("salesmaster", Context.MODE_PRIVATE)
        var remaining = prefs.getInt("remaining", 4)
        fun updateCounter() {
            counter.text = if (remaining > 0) "Free answers left: $remaining" else "Limit reached"
        }
        updateCounter()

        val savedApi = prefs.getString("apiUrl", "http://127.0.0.1:4242") ?: "http://127.0.0.1:4242"
        apiInput.setText(savedApi)

        fun setApi(newUrl: String) {
            prefs.edit().putString("apiUrl", newUrl).apply()
        }

        ask.setOnClickListener {
            val q = prompt.text.toString().trim()
            if (q.isEmpty()) {
                Toast.makeText(this, "Type an objection first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (remaining <= 0) {
                Toast.makeText(this, "Free limit reached", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val api = apiInput.text.toString().trim().ifEmpty { "http://127.0.0.1:4242" }
            setApi(api)

            // Build request to /ai-answer JSON: { prompt: "..." }
            val json = JSONObject(mapOf("prompt" to q)).toString()
            val req = Request.Builder()
                .url("$api/ai-answer")
                .post(RequestBody.create("application/json; charset=utf-8".toMediaTypeOrNull(), json))
                .build()

            client.newCall(req).enqueue(object: Callback {
                override fun onFailure(call: Call, e: IOException) {
                    // Fallback demo answer
                    runOnUiThread {
                        answer.text = "Demo answer (offline):
- Acknowledge the concern
- Reframe around value/ROI
- Provide proof or example
- Ask a closing question"
                        if (remaining > 0) {
                            remaining -= 1
                            prefs.edit().putInt("remaining", remaining).apply()
                            updateCounter()
                        }
                    }
                }
                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        val txt = try {
                            val body = it.body?.string() ?: ""
                            val obj = JSONObject(body)
                            obj.optString("text", body.ifBlank { "No response text" })
                        } catch (e: Exception) {
                            "No response text"
                        }
                        runOnUiThread {
                            answer.text = txt
                            if (remaining > 0) {
                                remaining -= 1
                                prefs.edit().putInt("remaining", remaining).apply()
                                updateCounter()
                            }
                        }
                    }
                }
            })
        }
    }
}
