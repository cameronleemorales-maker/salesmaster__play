package com.salesmaster.app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputObjection = findViewById<EditText>(R.id.inputObjection)
        val btnGetAnswer = findViewById<Button>(R.id.btnGetAnswer)
        val txtOutput = findViewById<TextView>(R.id.txtOutput)

        btnGetAnswer.setOnClickListener {
            val objection = inputObjection.text.toString().trim()
            if (objection.isEmpty()) {
                txtOutput.text = "Please enter a sales objection first."
                return@setOnClickListener
            }

            val demo = "Customer objection: \"" + objection + "\"\n\n" +
                "Suggested reply:\n" +
                "1) Acknowledge the concern.\n" +
                "2) Reframe around value/ROI specific to them.\n" +
                "3) Give a short proof point (story, metric, testimonial).\n" +
                "4) Ask a closing question to move forward."

            txtOutput.text = demo
        }
    }
}
